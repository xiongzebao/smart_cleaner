## Contributors
These are the active contributors of this project that you may contact if there is anything you need help with or if you have suggestions.

- [z3t0](https://github.com/z3t0) and currently also the main contributor.
  * Email: zetoslab@gmail.com
- [shirriff](https://github.com/shirriff): An amazing person who worked to create this awesome library and provide unending support
- [Informatic](https://github.com/Informatic)
- [fmeschia](https://github.com/fmeschia)
- [PaulStoffregen](https://github.com/paulstroffregen)
- [crash7](https://github.com/crash7)
- [Neco777](https://github.com/neco777)
- [Lauszus](https://github.com/lauszus)
- [csBlueChip](https://github.com/csbluechip) contributed major and vital changes to the code base.
- [Sebazzz](https://github.com/sebazz)
- [lumbric](https://github.com/lumbric)
- [ElectricRCAircraftGuy](https://github.com/electricrcaircraftguy)
- [philipphenkel](https://github.com/philipphenkel)
- [MCUdude](https://github.com/MCUdude)
- [adamlhumphreys](https://github.com/adamlhumphreys) (code space improvements)
- [marcmerlin](https://github.com/marcmerlin) (ESP32 port)
- [MrBryonMiller](https://github.com/MrBryonMiller)
- [bengtmartensson](https://github.com/bengtmartensson) providing support
- [AnalysIR](https:/github.com/AnalysIR) providing support
- [ArminJo](https://github.com/ArminJo) Maintainer
- [eshicks4](https://github.com/eshicks4)

Note: Please let [z3t0](https://github.com/z3t0) know if you have been missed.
